define("debug_tools", "jquery knockout set service underscore".split(" "), function(){ function f(){ } return{init:f}});
