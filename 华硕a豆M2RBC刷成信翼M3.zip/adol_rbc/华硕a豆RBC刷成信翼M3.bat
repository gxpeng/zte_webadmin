@echo off
cd /d %~dp0
adb shell "mount -o remount,rw /"
adb push  web      /etc_ro/
adb push  mmi      /etc_ro/
adb push  default  /etc_ro/
adb push  rc         /etc/
adb shell "chmod 755 /etc/rc"
adb push  goahead    /bin/
adb shell "chmod 755 /bin/goahead"
adb push  zte_mifi   /sbin/
adb shell "chmod 755 /sbin/zte_mifi"
adb push  zte_webadmin  /sbin/
adb shell "chmod 755 /sbin/zte_webadmin"
adb shell "nv erase"
adb shell "zte_webadmin &"
adb shell "reboot"
pause
